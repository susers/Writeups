<?php

if(!defined('Core_DIR')){
    exit();
}

function autoload_class($class){
	foreach(array('controller','model','view') as $dir){
		$file = APP_DIR.DS.'app'.DS.$dir.DS.$class.'.class.php';
		if(file_exists($file)){
			include $file;
			return;
		}
	}
}

function _if_debug($flag){
	if(!$flag){ 
		error_reporting(0);
		ini_set("display_errors", "Off");
		ini_set("log_errors", "On");
	}
}

function config($ini){
	foreach($ini as $key=>$value){
		ini_set($key,$value);
	}
}

function san($data){
	$htmldata=array();
	if(is_array($data)){
		foreach($data as $key => $value){
			$htmldata[$key]=htmlspecialchars($value);
		}
		return $htmldata;
	}
	if(is_string($data)){
		return htmlspecialchars($data);
	}
	
}


function init(){
	if(!file_exists(Cache_DIR)){
		mkdir(Cache_DIR);
	}
	if(!file_exists(Image_DIR)){
		#echo Image_DIR."\n";
		#echo Upload_DIR."\n";
		mkdir(Image_DIR);
		mkdir(Upload_DIR);
	}

	if(!file_exists(Upload_DIR)){
		mkdir(Upload_DIR);
	}
}