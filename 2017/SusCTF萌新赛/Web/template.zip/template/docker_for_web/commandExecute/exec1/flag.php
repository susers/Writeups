<?php
$flag="Susctf{C0mm4nd_3x3cu7i0n}";
