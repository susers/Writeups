#!/bin/bash

docker build -t xman-web5 .
docker run -it -p 8004:80 xman-web5