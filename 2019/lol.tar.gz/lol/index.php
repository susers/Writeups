<?php
defined('DS') or define('DS', DIRECTORY_SEPARATOR);
define('APP_DIR', realpath('./'));
define('Cache_DIR',APP_DIR.DS.'user');
define('View_DIR',APP_DIR.DS.'app'.DS.'view');
define('Core_DIR',APP_DIR.DS.'core');
define('Image_DIR',APP_DIR.DS.'upload');
include(Core_DIR.DS.'core.php');