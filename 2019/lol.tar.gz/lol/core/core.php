<?php

if(!defined('Core_DIR')){
    exit();
}

include(Core_DIR.DS.'config.php');
include(Core_DIR.DS.'func.php');

_if_debug($config['debug']);
spl_autoload_register('autoload_class');
config($config['ini']);


session_start();
define('Upload_DIR',Image_DIR.DS.session_id());
init();

$app = new IndexController();

if(method_exists($app, $app->data['method'])){
	$app->{$app->data['method']}($app->data['param']);
}else{
	$app->index();
}

#$this->method($_POST)