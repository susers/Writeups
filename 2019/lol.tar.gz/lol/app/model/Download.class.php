<?php
class Download{
    public $filename;

    function __construct($filename){
        $this->filename=$filename;
        $this->filename=str_replace('\\', '/',$this->filename);
        #cho $this->filename;
        # windows环境下遇到的真实案例，因为windows下\代表路径。win环境下配置注释掉 str_replace 即可。
        $this->download();
    }

    public function download(){
        if(file_exists($this->filename) && is_file($this->filename)){
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream'); 
            header('Content-Disposition: attachment; filename='.basename($this->filename));
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: '.filesize($this->filename));
            echo file_get_contents($this->filename);
        }else{
            exit('请上传个人图片');
        }
        
    }
}