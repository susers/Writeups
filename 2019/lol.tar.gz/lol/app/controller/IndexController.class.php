<?php
class IndexController{
    public $data;

    function __construct(){
        $this->url=explode('/',$_SERVER['REQUEST_URI']);
        $this->data['method']=san(empty($this->url['1'])?'index':$this->url['1']);
        $this->data['param']=san(isset($this->url['2'])?$this->url['2']:'');
        
        $this->data['post']=san($_POST);
        $this->data['image']=$_FILES;

        #print_r($_SESSION);
    }

    public function index(){
        $this->index=Core_DIR.DS.'html.php';
        include($this->index);
    }

    public function post($param){
        $this->Files=new Files($this->data['image']);
        $this->data['image']=$this->Files->file_dir;
        new Cache($this->data);
    }

    public function download($param){
        new Download(Upload_DIR.DS.$this->data['param']);
    }

    function __destruct(){
        unset($this->data);

    }
}