##  Title
give me the goods
##  Tools
firefox或chrome

##  Steps

- Step 1

访问ti3.php?goods=flag即可获得flag



