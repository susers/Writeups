<?php
$flag="CTF{flag_web1_hehe}";
