﻿##  Title
Simple SQLi
##  Tools
firefox或chrome

##  Steps


右键点击查看源码

```html
<html>
<head>
welcome to simplexue
</head>
<body>
<p>You are not admin!</p><!-- web11.php.bak-->
<form method=post action=''>
<input type=text name=user value="Username">
<input type=password name=pass value="Password">
<input type=submit>
</form>
</body>
</html>
```

注释部分提示有备份文件web11.php.bak

下载后可得源码：
```php
<html>
<head>
welcome to simplexue
</head>
<body>
<?php

$user = $_POST[user];
$pass = md5($_POST[pass]);

$sql = "select user from php where (user='$user') and (pw='$pass')";
$query = mysql_query($sql);
if (!$query) {
	printf("Error: %s\n", mysql_error($conn));
	exit();
}
$row = mysql_fetch_array($query, MYSQL_ASSOC);
//echo $row["pw"];
  if($row['user']=="admin") {
    echo "<p>Logged in! Key: *********** </p>";
  }

  if($row['user'] != "admin") {
    echo("<p>You are not admin!</p>");
  }
}

?>
<form method=post action=index.php>
<input type=text name=user value="Username">
<input type=password name=pass value="Password">
<input type=submit>
</form>
</body>
<a href="index.txt">
</html>
```

其中没有做任何过滤，可以构造用户名为') or 1=1#,密码任意，登录即可获得flag。


