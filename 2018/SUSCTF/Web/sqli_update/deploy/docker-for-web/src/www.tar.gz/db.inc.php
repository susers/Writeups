<?php
/**
 * Created by PhpStorm.
 * User: image
 * Date: 18-3-17
 * Time: 下午1:00
 */
$hostname="localhost";
$dbuser="root";
$dbpass="toor";
$database="demo2";
$mysqli=new mysqli($hostname,$dbuser,$dbpass,$database);

