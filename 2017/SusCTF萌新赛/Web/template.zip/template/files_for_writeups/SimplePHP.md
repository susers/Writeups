﻿##  Title
Simple php
##  Tools
firefox或chrome(安装hackbar)

##  Steps

- Step 1

打开后可以看到漏洞出现在parse_str函数上，parse_str函数会将形如aaa=bbb的字符串转化为$aaa='bbb'的形式。
- Step 2

构造payload为
```
?heetian=he%3dabcd
```
其中%3d为等于号的url编码值，访问即可得到flag。 



