<?php
$config=array(
	'debug'=>'false',
	'ini'=>array(
		'session.name' => 'PHPSESSID',
		'session.serialize_handler' => 'php'
	)
);
