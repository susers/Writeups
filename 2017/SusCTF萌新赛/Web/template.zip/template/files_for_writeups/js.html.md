##  Title
FuckingJs
##  Tools
firefox或chrome

##  Steps

- Step 1

右键点击查看源码

- Step 2

在注释的标签中复制<script></script>

- Step 3

F12进入控制台，将复制的内容粘贴后运行即可获得flag。





