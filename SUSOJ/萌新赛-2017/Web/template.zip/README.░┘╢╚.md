### Title
> 百度一下,你就知道

### Description
>百度一下

### Category
> ti1.php

### Deployment
> offline|online                                         **online模式下，flag可不写，但需要写分值，分值数量需要和场景描述文件中请求的flag数量一致**

### Flag
> Susctf{flag_hide_in_comments}

### Score
> 50

### Hint
> ctrl+F

### Attachment
> 


