### Title
> givemegoods

### Description
不难

### Category
> ti1.php

### Deployment
> offline|online                                         **online模式下，flag可不写，但需要写分值，分值数量需要和场景描述文件中请求的flag数量一致**

### Flag
> Susctf{request_params}
### Score
> 50

### Hint
> 给我正确的goods   

### Attachment
> 


