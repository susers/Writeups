##  Title
easyweb
##  Tools
firefox或chrome

##  Steps

- Step 1

右键点击审查元素

- Step 2

点击网络，重新载入之后点击该请求即可在header中发现flag。




